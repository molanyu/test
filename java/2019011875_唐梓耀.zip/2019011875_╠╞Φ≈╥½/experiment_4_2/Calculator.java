package experiment_4_2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Calculator extends JFrame {

	private JPanel contentPane;
	private JTextField answerline;
	private JButton reciprocal;
	private double a;
	private double b;
	private double answer;
	private int flag=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculator frame = new Calculator();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculator() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		answerline = new JTextField();
		answerline.setEditable(false);
		answerline.setBounds(10, 10, 416, 33);
		contentPane.add(answerline);
		answerline.setColumns(10);

		JPanel operationline = new JPanel();
		operationline.setBounds(10, 53, 416, 33);
		contentPane.add(operationline);
		operationline.setLayout(new GridLayout(1, 0, 0, 0));

		JButton Back = new JButton("Back");
		Back.setForeground(Color.BLUE);
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				answerline.setText(answerline.getText().substring(0,answerline.getText().length()-1));
			}
		});
		operationline.add(Back);

		JButton CE = new JButton("CE");
		CE.setForeground(Color.BLUE);
		CE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				answerline.setText("");
			}
		});
		operationline.add(CE);

		JButton C = new JButton("C");
		C.setForeground(Color.BLUE);
		C.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				answerline.setText("");
				a=0;
				flag=0;
			}
		});
		operationline.add(C);

		JButton About = new JButton("About");
		About.setForeground(Color.BLUE);
		operationline.add(About);

		JPanel panel = new JPanel();
		panel.setBounds(10, 96, 204, 157);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(0, 3, 0, 0));

		JButton []button=new JButton[10];
		for(int i=0;i<10;i++) {
			button[i]=new JButton(i+"");
			String str=i+"";
			button[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					answerline.setText(answerline.getText()+str);
				}
			});
			panel.add(button[i]);
		}

		JButton reverse = new JButton("+/-");
		panel.add(reverse);

		JButton dot = new JButton(".");
		dot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				answerline.setText(answerline.getText()+".");
			}
		});
		panel.add(dot);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(224, 96, 202, 157);
		contentPane.add(panel_1);
		panel_1.setLayout(new GridLayout(0, 2, 0, 0));

		JButton divide = new JButton("/");
		divide.setForeground(Color.RED);
		divide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a=Integer.parseInt(answerline.getText());
				answerline.setText("");
				flag=4;
			}
		});
		panel_1.add(divide);

		JButton sqrt = new JButton("sqrt");
		sqrt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a=Integer.parseInt(answerline.getText());
				answerline.setText("2");
				flag=5;
			}
		});
		panel_1.add(sqrt);

		JButton multiple = new JButton("*");
		multiple.setForeground(Color.RED);
		multiple.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a=Integer.parseInt(answerline.getText());
				answerline.setText("");
				flag=3;
			}
		});
		panel_1.add(multiple);

		JButton percent = new JButton("%");
		percent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a=Integer.parseInt(answerline.getText());
				answerline.setText("");
				flag=6;
			}
		});
		panel_1.add(percent);

		JButton minus = new JButton("-");
		minus.setForeground(Color.RED);
		minus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a=Integer.parseInt(answerline.getText());
				answerline.setText("");
				flag=2;
			}
		});
		panel_1.add(minus);

		reciprocal = new JButton("1/x");
		reciprocal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a=Integer.parseInt(answerline.getText());
				answerline.setText("0");
				flag=7;
			}
		});
		panel_1.add(reciprocal);

		JButton add = new JButton("+");
		add.setForeground(Color.RED);
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a=Integer.parseInt(answerline.getText());
				answerline.setText("");
				flag=1;
			}
		});
		panel_1.add(add);

		JButton equals = new JButton("=");
		equals.setForeground(Color.RED);
		equals.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				b=Integer.parseInt(answerline.getText());
				if(flag==0)
				{
					answerline.setText(String.valueOf(a));
				}else if(flag==1)
				{
					answerline.setText(String.valueOf(a+b));
				}
				else if(flag==2)
				{
					answerline.setText(String.valueOf(a-b));
				}
				else if(flag==3)
				{
					answerline.setText(String.valueOf(a*b));
				}
				else if(flag==4)
				{
					answerline.setText(String.valueOf(a/b));
				}
				else if(flag==5)
				{
					answerline.setText(String.valueOf(Math.sqrt(a)));
				}
				else if(flag==6)
				{
					answerline.setText(String.valueOf(a%b));
				}
				else if(flag==7)
				{
					answerline.setText(String.valueOf(1/a));
				}
			}
		});
		panel_1.add(equals);
	}

}
