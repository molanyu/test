package experiment_4_3;

public class MainClass {
public static void main(String[] args) {
   ComputerJFrame frame;
   frame = new ComputerJFrame("算术测试");
}
}
