package experiment_5_3;

public class test {
	public static void main(String args[])
	{  CCustomer c1=new CCustomer();
	CCustomer c2=new CCustomer();
	c1.start();   c2.start();
	}
}
class CBank
{     private static int sum=0;
public static void add(int n){
	int tmp=sum;
	tmp=tmp+n;   // 累加汇款总额
	try{
		Thread.sleep((int)(10000*Math.random()));  // 小睡几秒钟
	}
	catch(InterruptedException e){} 
	sum=tmp;
	System.out.println("sum= "+sum); 
}
}
class CCustomer extends Thread // CCustomer类，继承自Thread类
{  public void run(){    // run() method
	for(int i=1;i<=3;i++)
		CBank.add(100);  // 将100元分三次汇入
}
}

