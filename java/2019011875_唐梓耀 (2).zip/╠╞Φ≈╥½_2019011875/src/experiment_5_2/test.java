package experiment_5_2;

public class test {

	public static void main(String[] args) {
		Runner impl = new Runner();
		for(int i=2;i<11;i++) 
			new Thread(impl,i+"").start();
	}
	
}
class Runner implements Runnable {
	private int ticket = 1000;
	public synchronized void sell() {
		if(ticket>0) {
			System.out.println("第"+Thread.currentThread().getName()+"售票点卖出了第"+ticket+"张票");
			ticket--;
		}
	}
	@Override
	public void run() {
		while(ticket>0){
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			sell();
		}
	}
}
