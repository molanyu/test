package experiment_5_4;

public class test {
	static Thread t1 = null, t2 = null;
	public static void main(String[] args) {
		Object lock=new Object();
		t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                while(true) {
                    synchronized (lock) {
                        System.out.println("A");
                        lock.notify();
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                while(true) {
                    synchronized (lock) {
                        System.out.println("B");
                        lock.notify();
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
        t1.start();
        t2.start();
	}

}


