package experiment_1;

import java.util.LinkedList;

import java.util.Iterator;

public class test {
	public static void main(String[] args) {
		LinkedList<Person> list=new LinkedList<Person>();
		list.add(new Person("����","12310001"));
		list.add(new Student("����","12320002","89","93","94"));
		list.add(new Teacher("����","12330003","4000.0"));
		Iterator<Person> it=list.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		System.out.println("after addfirst:");
		list.addFirst(new Person("joke","2019011875"));
		it=list.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		list.removeFirst();
		System.out.println("after removefirst:");
		it=list.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		list.addLast(new Person("joke","2019011875"));
		System.out.println("after addlast:");
		it=list.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		list.removeLast();
		System.out.println("after removelast:");
		it=list.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
}
class Person implements Comparable<Object>
{
	String name,id;
	public Person(String name, String id) {
		super();
		this.name = name;
		this.id = id;
	}

	@Override
	public String toString() {
		return "������" + name +" ����֤�ţ�" + id ;
	}


	@Override
	public int compareTo(Object arg0) {
		Person other=(Person)arg0;
		return (id.compareTo(other.id));
	}

}
class Student extends Person
{
	String chinese,math,english;

	public Student(String name, String id, String chinese, String math, String english) {
		super(name, id);
		this.chinese = chinese;
		this.math = math;
		this.english = english;
	}

	@Override
	public String toString() {
		return "������" + name+" ����֤�ţ�" + id +" ���ģ�"+ chinese +"��ѧ��"+ math +"Ӣ��"+ english;
	}

}
class Teacher extends Person
{ 
	String salary;

	public Teacher(String name, String id, String salary) {
		super(name, id);
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "������" + name +" ����֤�ţ�" + id +" ����"+ salary;
	}

}