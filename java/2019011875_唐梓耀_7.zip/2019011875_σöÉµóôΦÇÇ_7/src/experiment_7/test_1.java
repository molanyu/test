package experiment_7;

import java.io.FileReader;
import java.io.IOException;
public class test_1 {
	/** Defines the entry point of the program. */
	public static void main(String[] args) {
		System.out.println("Please enter the file path:");
		try {
			String fileName = "";
			while(true) {
				int readByte = System.in.read();//1:获取单个字符    
				if(readByte == -1 || readByte == '\r')//2:如果输入-1或换行则终止循环
					break;
				fileName += (char) readByte;//3:创建文件名
			}
			// Reads the file and prints it to the System.out stream.
			char[] buffer = new char[20];//4:创建字符数组
			FileReader reader = new FileReader(fileName);//5:以文件输入流类打开该文件
			while(true) {
				int length = reader.read(buffer);//6:将文件内容读取至字符数组，并获取成功读取字符个数
				if(length < 0) // Reads a long as there is more data.
					break;
				String text = new String(buffer, 0, length);//7:将char字符数组内的有效内容转换为字符串
				System.out.print(text);
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

