package experiment_7;

import java.io.*;


public class test_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Student a=new Student(666,"joke",18);
			Student b=new Student(2001,"john",20);
			ObjectOutputStream ow=new ObjectOutputStream(new FileOutputStream("E:\\java_test\\student.txt"));
			ow.writeObject(a);
			ow.writeObject(b);
			ow.close();
			ObjectInputStream oi=new ObjectInputStream(new FileInputStream("E:\\java_test\\student.txt"));
			Student new_a=(Student)oi.readObject();
			Student new_b=(Student)oi.readObject();
			System.out.println(new_a.toString());
			System.out.println(new_b.toString());
			oi.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
class Student implements Serializable{
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private int age;
	
	public Student() {
		
	}

	public Student(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	
	
}