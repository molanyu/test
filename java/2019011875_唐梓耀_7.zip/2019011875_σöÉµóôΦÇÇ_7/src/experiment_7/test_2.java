package experiment_7;
import java.io.*;

public class test_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			char []ch=new char[1000];
			BufferedReader br=new BufferedReader(new FileReader("E:\\java_test\\test.txt"));
			BufferedWriter bw=new BufferedWriter(new FileWriter("E:\\java_test\\output.txt"));
			br.read(ch);
			bw.write(ch);
			br.close();
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
