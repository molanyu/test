package experiment_7;
import java.io.*;
public class test_3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileRWTest a=new FileRWTest();
		a.init();
	}

}

class FileRWTest{
	public void init() {
		try {
			FileReader infile=new FileReader("E:\\java_test\\test.txt");
			FileWriter outfile=new FileWriter("E:\\java_test\\output_test.txt");
			int ch;
			int cnt1,cnt2;
			cnt1=cnt2=0;
			while((ch=infile.read())!=-1) {
				if(ch>='a'&&ch<='z') {
					cnt1++;
					outfile.write((char)ch-'a'+'A');
				}
				else if(ch>='A'&&ch<='Z') {
					cnt2++;
					outfile.write((char)ch);
				}
				else {
					outfile.write((char)ch);
				}
			}
			infile.close();
			outfile.close();
			System.out.println("小写字母个数："+cnt1);
			System.out.println("大写字母个数："+cnt2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
